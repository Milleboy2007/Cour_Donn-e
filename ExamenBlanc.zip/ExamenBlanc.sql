/***
Examen blanc


-- Question 1 : Création de requête
-- ********************************

Écrire une requête affiche les enmployés qui travaillent en ingérierie, c'est-à-dire que le titre de leur poste (JobTitle) contient "Engineer" et qui sont des femmes.
On affichera : 
	- La civilité (Title), 
	- le nom (LastName), 
	- le prénom (FirstName), 
	- le titre du poste (JobTitle), 
	- Genre (Gender)

-- Votre code ici */



/* ---------------------------------------------------------------------------------------------------------
-- Question 2 : Création de vue
-- ****************************

Créer une vue vAdresseCompleteEmploye qui contient l'adresse complète des employés
La vue contient :

	- Le numéro d'entité (BusinessEntityID)
	- La civilité (Title),
	- Le nom de L'employé (LastName),
	- Le prénom de l'employé (FirstName),
	- L'adresse (AddressLine1),
	- La ville (City) ,
	- Le code postal (PostalCode) ,
	- Le type d'adresse (Name) TypeAdresse,
	- La province, région (Name)	ProvinceRegion,
	- L'Adresse email,
	- Le téléphone,
	- Le type de téléphone (Name) TypeTelephone

-- Votre code ici -- */


/*
Afficher le contenu de la vue. La liste sera triée par le nom de l'employé.

-- Votre code ici -- */



/* -----------------------------------------------------------------------------------------------
-- Question 3 : Création de table
-- ******************************
A-
Créer dans cette nouvelle table nommée tblEmployeInfo.
Cette table contiendra les informations suivantes :
	- Le numéro d'entité (BusinessEntityID)
	- Le numéro d'identité national (NationalIDNumber)
	- La civilité (Title),
	- Le nom de L'employé (LastName),
	- le poste de l'employé (JobTitle)
	- Le genre (Gender)
	- Le statut marital (MaritalStatus)
	- La date d'embauche (HireDate)
	- Les heures de vacances (VcacationHours)
	- Les heures de maladie (SickLeaveHours)

-- Votre code ici -- */


/*
B- Vérifier la création de cette nouvelle table dans le nouvelle base de données.

-- Votre code ici --*/


/*
-- -----------------------------------------------------------------------------------------------------------
C- Modifier la table tblEmployeInfo pour rajouter une clé primaire sur la colonne :
	- Le numéro d'entité (BusinessEntityID)

-- Votre code ici --*/


/*
D - Modifier la table tblEmployeInfo pour rajouter les colonnes suivantes :
	- GenreComplet de type texte de longueur 20
	- StatutMaritalComplet de type texte, de longueur 20
	- JoursMaladie de type nombre décimal
	- JoursVacances de type nombre décimal

-- Votre code ici -- */


/* --------------------------------------------------------------------------------------------------------------
E- Mise à jour de données

Effectuez les mises à jour suivantes sur la table tblEmployeInfo :
	- Mettre à jour la colonne StatutMaritalComplet avec 'Single' lorsque MaritalStatus est 'S' et 'Married' lorsque le MaritalStatus est 'M'
	- Mettre à jour la colonne GenreComplet avec 'Male' lorsque Gender est 'M' et 'Female' lorsque Gender est 'F'
	- Mettre à jour la colonne JoursMaladie à partir de la colonne SickLeaveHours
	- Mettre à jour la colonne JoursVacances à partir de la colonne VacationHours

Note : Pour les deux dernières mises à jour, il s’agit de convertir les heures de maladie (SickLeaveHours) et de vacances (VacationHours) en jours de maladie et de vacances. 
Une journée de travail comporte 7.5h.

-- Votre code ici --*/


/* --------------------------------------------------------------------------------------------------------------
-- Question 4 : Création de tables
-- *******************************

Créer les tables suivantes :
	- Une table qui contient des marques de voitures (tblMarques)
	- Une table qui contient les voitures (tblVoitures)
	- Une table qui contient les propriétaires des voitures (tblProprietaires)

Structure des tables
La table tblMarques
	- NoMarque entier clé primaire auto incrémenté
	- NomMarque chaine de caractères longueur 20 doit contenir une valeur
	- PaysMarque chaine de caractères longueur 20

La table tblVoitures
	- NoSerie entier cle primaire auto incrementé
	- ModeleVoiture Chaine de caracteres long 20 doit contenir une valeur
	- CouleurVoiture Chaine de long 20 
	- Motorisation
	- TypeVoiture
	- NoMarque Cle étrangere

La table tblProprietairesVoiture
	- NoProprietaire entier cle primaire auto inc
	- NomProprietaire Chaine de caractere 25
	- PrenomProprietaire Chaine de caractere 25
	- NoSerie entier cle étrangere

-- Votre code ici -- */


/* --------------------------------------------------------------------------------------------------------------
-- Question 5 : Insertion de données
-- *********************************

Écrire le code pour insérer les données suivantes dans les tables créées à la Question 4

tblMarques
NoMarque	NomMarque		Pays
1			BMW				Allemagne
2			Mercedes0Benz	Allemagne
3			Lexus			Japon

tblVoitures
NoSerie		ModeleVoiture	ColuleurVoiture		Motorisation	TypeVoiture	NoMarque
1			750 iL			Gris				V8				Berline		1
2			Maybach			Bleu/blanc			V12				Limousine	2
3			S500			Noir				V8				Berline		2


tblProprietaires
NoProprietaire	NomProprietaire	PrenomProprietaire	NoSerie
1				Doe				John				1
2				Doe				Jane				3
3				Blow			Joe					1

-- Votre code ici -- */




/******************************************** FIN DE L'EXAMEN ********************************************
