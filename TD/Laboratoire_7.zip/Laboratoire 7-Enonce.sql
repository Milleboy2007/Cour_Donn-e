-- ==============================================================================
-- Description du cours : Introduction au bases de donn�es
-- Code du cours : 420-212-MV
-- Laboratoire 7
-- Calcul de boni des employ�s de la compagnie Pages bleues
-- ==============================================================================


-- Objectif : 
-- **********
-- Ce Laboratoire vise � r�soudre un probl�me d'entreprise
-- en utilisant les notions de base de donn�es vues en cours
-- ========================================================

-- Base de donn�es � utiliser : Bonis


-- ******************************************************************************************
-- �crire une requ�te affiche les donn�es des employ�s suivantes
-- ******************************************************************************************
-- No employ�
-- Le nom de l'employ�
-- Le pr�nom de l'employ�
-- Le num�ro du poste de l'employ�
-- La description du poste de l'employ�
-- Le d�partement de l'employ�
-- Le taux horaire
-- Le nombre de semaine travaill�es
-- Le salaire annuel

	
-- Cr�er une table temporaire qui contient les employe�s syndiqu�s


-- V�rifier la cr�ation de la nouvelle table

-- Modifier la structure de la table tempEmpSyndiques en ajoutant les colonnes suivantes :
-- Le montant des gains 
-- Le pourcentage de la commission
-- Le montant de la commission


-- V�rifier et afficher la nouvelle structure

-- **************************************
-- Traitement des employ�s syndiqu�s
-- *************************************
-- Calculer la commission que les employ�s syndiqu�s recevront
-- On affichera :
-- Toutes les colonnes de la table tempEmpSyndiques
-- Le montant des ventes r�alis�es
-- Le pourcentage de la commission
-- Le montant des gains
-- Le montant de la commission
 
 -- Effectuer la mise � jour du montant des gains
 -- Quelle est l'expression qui permet de calculer le montant des gains ?
 -- Taux horaire * Nb Heures par sem * Nb de sem

 -- V�rifier la mise � jour


 -- Effectuer la mise � jour du pourcentrage de la commission

-- V�rifier la mise � jour du pourcentage de la commission


 -- Efectuer la mise � jour du montant de la commission


-- V�rifier la mise � jour du montant de la commission


-- Cr�er une table qui contient les employ�s non syndiqu�s


-- V�rifier la cr�ation de la nouvelle table


-- Modifier la structure de la table temEmpNonSyndiques en ajoutant les colonnes suivantes :
-- Le montant des gains 
-- Le pourcentage du boni
-- Le montant du boni


-- V�rifier et afficher la nouvelle structure



-- *********************************************
-- *** Traitement des employ�s non syndiqu�s ***
-- *********************************************
-- Calculer le boni que les employ�s non syndiqu�s recevront
-- On affichera :
-- Toutes les colonnes de la table tempEmpNonSyndiques
-- Le montant des gains
-- Le pourcentage du boni
-- Le montant du boni
 
 -- Effectuer la mise � jour du montant des gains
 -- Quelle est l'expression qui permet de calculer le montant des gains ?
 -- Taux horaire * Nb Heures par sem * Nb de sem


 -- V�rifier la mise � jour

-- Effectuer la mise � jour du pourcentage du boni


-- V�rifier la mise � jour

 -- Efectuer la mise � jour du montant du boni


-- V�rifier la mise � jour du montant du boni


-- ***************  Cr�ation de la table des paiements (tblEmpPaiement)


--Ajout des montant des employ�s syndiqu�s


--Ajout des montants des employ�s non syndiqu�s


-- V�rification de la table des paiements



-- Nettoyage de l'environnement
-- Suppression des tables temporaires



-- ************************  FIN de PROGRAMME *************************

